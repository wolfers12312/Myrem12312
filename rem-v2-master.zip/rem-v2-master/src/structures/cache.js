/**
 * Created by Julian/Wolke on 03.01.2017.
 */
class Cache extends Map {
    constructor() {
        super();
    }
}
module.exports = new Cache();