/**
 * Created by Julian/Wolke on 05.01.2017.
 */
let EventEmitter = require('eventemitter3');
class Module extends EventEmitter {
    constructor() {
        super();

    }
}
module.exports = Module;