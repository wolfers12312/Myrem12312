/**
 * Created by Julian/Wolke on 18.01.2016.
 */
let Manager = require('../../structures/manager');
class SearchManager extends Manager {
    constructor() {
        super();
    }

    searchUser() {

    }

    searchChannel() {

    }

    searchGuild() {

    }
}
module.exports = {class: SearchManager, deps: [], async: false, shortcode: 'sem'};