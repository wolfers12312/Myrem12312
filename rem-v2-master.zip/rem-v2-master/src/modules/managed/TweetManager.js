/**
 * Created by Julian/Wolke on 10.11.2016.
 */
let Manager = require('../../structures/manager');
class TweetManager extends Manager {
    constructor() {
        super();
    }

}
module.exports = {class: TweetManager, deps: [], async: false, shortcode: 'tm'};