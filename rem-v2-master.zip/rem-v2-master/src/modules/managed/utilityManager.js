/**
 * Created by julia on 23.01.2017.
 */
let Manager = require('../../structures/manager');
class UtilityManager extends Manager {

}
module.exports = {
    class: UtilityManager,
    deps: [],
    async: false,
    shortcode: 'utm'
};