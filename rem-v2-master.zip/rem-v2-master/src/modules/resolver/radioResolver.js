/**
 * Created by julia on 19.02.2017.
 */
let BasicImporter = require('../../structures/basicImporter');
class RadioResolver extends BasicImporter {
    constructor(msg) {
        super();
    }

}